Modified LedControl
==========
Added a greater range of characters. Support for double-wide characters (like M and W).


LedControl
==========
LedControl is an [Arduino](http://arduino.cc) library for MAX7219 and MAX7221 Led display drivers.

Documentation
-------------
The documentation is built using [Sphinx](http://sphinx-doc.org/) and made available Online 
by the great [Read The Docs](http://readthedocs.org/) project.

Download
--------
~~The lastest binary version of the Library is always available on the 
[Download Page](https://github.com/wayoda/LedControl/downloads) of the project.~~

Oops,that feature is gone on Github!
Please, get the library from the [Arduino Playground](http://playground.arduino.cc/Main/LedControl) pages:

[LedControl.zip](http://arduino.cc/playground/uploads/Main/LedControl.zip)


Install
-------
Unzip the library to the `libraries`-folder of you arduino `sketchbook`-folder








